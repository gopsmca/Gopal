package com.demo.spring;

import org.springframework.stereotype.Service;

@Service
public class Singer implements Performer {

	@Override
	public void perform() {
		// TODO Auto-generated method stub

		System.out.println("The Singer is Singing la..la..la");
	}

}
