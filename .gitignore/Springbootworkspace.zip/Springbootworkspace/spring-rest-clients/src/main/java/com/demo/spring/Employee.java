package com.demo.spring;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employee {

	private int empId;
	private String empName;
	private String city;
	private double salary;
	
	public Employee(){
		
	}
	
	
	public void setEmpID(int empID){
		this.empId=empId;
	}
	
	public int getEmpId(){
		return this.empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getCity() {
		return city;
	}

	public Employee(int empId, String empName, String city, double i) {
		this.empId = empId;
		this.empName = empName;
		this.city = city;
		this.salary = i;
	}


	public void setCity(String city) {
		this.city = city;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}
}
