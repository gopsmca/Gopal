package com.demo.spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository
public class EmpDaoJdbcImpl implements EmpDao {

	@Autowired
	JdbcTemplate jt;
	
	@Override
	public String save(Emp e) {
		
		int count = jt.update(new PreparedStatementCreator(){
			
			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException
			{
				
				PreparedStatement pst = conn.prepareStatement("insert into EMP(empno, name, address, salary) values(?,?,?,?)");
				pst.setInt(1, e.getEmpId());
				pst.setString(2, e.getName());
				pst.setString(3, e.getCity());
				pst.setDouble(4,  e.getSalary());
				
				return pst;
				
			}
			
		});
		
		if(count == 1)
		{
			return "JDBC:Emp Saved with ID:" +e.getEmpId();
		}
		else
		{
			return "Error";
		}
	}

	@Override
	public Emp findOne(int empId) {
		
		Emp e = jt.queryForObject("select * from emp where empno ="+200, new RowMapper<Emp>(){
			
		@Override
		public Emp mapRow(ResultSet rs, int idx) throws SQLException
			{
				return new Emp(rs.getInt("EMPNO"), rs.getString("NAME"), rs.getString("ADDRESS"), rs.getDouble("SALARY"));
			}
			
		});
		
		return e;
	}

	@Override
	public String delete(int empId) {
		
		jt.execute("delete from emp where empno=" +empId);
		
		return "Delete Done";
	}

	@Override
	public List<Emp> getAll() {
		
		List<Emp> empList = jt.query("Select * from emp", new RowMapper<Emp>(){
			
			@Override
			public Emp mapRow(ResultSet rs, int idx) throws SQLException
			{
				return new Emp(rs.getInt("EMPNO"), rs.getString("NAME"), rs.getString("ADDRESS"), rs.getDouble("SALARY"));
			}
			
		});
		return empList;
	}

	@Override
	@Transactional
	public String saveAll(List<Emp> empList) {
		
		for(Emp e:empList)
		{
			save(e);
		}
		return "Done";
	}

}
