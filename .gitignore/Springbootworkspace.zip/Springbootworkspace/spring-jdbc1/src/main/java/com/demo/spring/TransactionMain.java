package com.demo.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TransactionMain {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmpDao  dao = (EmpDao)ctx.getBean("empDaoJdbcImpl");
		
		List<Emp> empList = new ArrayList<Emp>();
		empList.add(new Emp(15, "A","Delhi",45000));
		empList.add(new Emp(25, "B","Bombay",55000));
		empList.add(new Emp(35, "C","Chennai",65000));
		empList.add(new Emp(45, "D","Banglore",75000));
		
		dao.saveAll(empList);
	}

}
