package com.demo;

public class ThreadDemo {

	public static void main(String[] args) {
		
		//Thread t = new Thread(new Worker());
		//t.start();
		Thread t1 = new Thread(()->{
		
			
				try
				{
					for (int i=0;i<5;i++)
					{
						System.out.println(Thread.currentThread().getName()+" " +i);
						Thread.sleep(1000);
					}
				}
				catch(InterruptedException e)
				{
					e.printStackTrace();
				}
			
			
		});
		t1.start();
	}

}

class Worker implements Runnable
{
	@Override
	public void run()
	{
		try
		{
			for (int i=0;i<5;i++)
			{
				System.out.println(Thread.currentThread().getName()+" " +i);
				Thread.sleep(1000);
			}
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}
	
}