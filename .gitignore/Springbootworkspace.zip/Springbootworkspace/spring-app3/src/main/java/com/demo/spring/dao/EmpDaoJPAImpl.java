package com.demo.spring.dao;

import org.springframework.stereotype.Repository;


import com.demo.spring.entity.Emp;

@Repository("jpa")
public class EmpDaoJPAImpl implements EmpDao{
	
	
@Override
public String saveEmp(Emp e)
{
	return "JPA: Emp Saved with id: " + e.getEmpId();
}
	
}
