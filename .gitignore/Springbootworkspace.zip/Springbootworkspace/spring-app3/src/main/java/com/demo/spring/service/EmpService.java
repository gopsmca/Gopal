package com.demo.spring.service;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import com.demo.spring.dao.EmpDao;
import com.demo.spring.entity.Emp;

@Service
public class EmpService implements BeanNameAware,ApplicationContextAware {
	
	@Autowired
	@Qualifier("jpa")
	EmpDao dao;
	
//	public void setDao(EmpDao dao)
//	{
//		this.dao = dao;
//	}
	
	public String registerEmp(int id, String name, String city, double salary)
	{
		return dao.saveEmp(new Emp(id,name,city,salary));
	}

	@Override
	public void setBeanName(String name) {
		// TODO Auto-generated method stub
		System.out.println("The Bean Name :" +name);
	}

	@Override
	public void setApplicationContext(ApplicationContext ctx) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("Bean Aliases: "+ctx.getAliases("empService").length);
	}
	
	

}
