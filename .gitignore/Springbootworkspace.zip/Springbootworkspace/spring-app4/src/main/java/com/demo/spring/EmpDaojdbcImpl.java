package com.demo.spring;

import org.springframework.stereotype.Repository;

@Repository
public class EmpDaojdbcImpl implements EmpDao {
	
	public String saveEmp(Employee e){
		System.out.println("Employee with id"+ e.getEmpId() + "is Saved");
		return "Saved";
	}

}
