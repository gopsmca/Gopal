package com.demo.spring;

public interface EmpDao {
	public String saveEmp(Employee e);
}
