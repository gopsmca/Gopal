package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ApplicationContext ctx = new ClassPathXmlApplicationContext("context.xml");
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmpService service1 = (EmpService)ctx.getBean(EmpService.class);
		
		System.out.println(service1.registerredEmpployee(1000, "Madhu", "Hyderabad", 50000));
	}

}
