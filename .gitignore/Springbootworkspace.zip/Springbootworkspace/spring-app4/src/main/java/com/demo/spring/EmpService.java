package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("app")
public class EmpService {
	@Autowired
	@Qualifier("EmpDaojdbcImpl")
	
	EmpDao dao;
	 
	 
	/*public EmpDao getDao() {
		return dao;
	}


	public void setDao(EmpDao dao) {
		this.dao = dao;
	}
*/

	public String registerredEmpployee(int id,String name,String city,double salary){
		String resp = dao.saveEmp(new Employee(id,name,city,salary));
		if(resp.equals("saved"))
			return "Emp Registered";
		return "problem Occured";
	}
}
