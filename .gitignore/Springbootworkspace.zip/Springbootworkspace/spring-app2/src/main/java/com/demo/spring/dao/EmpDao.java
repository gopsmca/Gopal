package com.demo.spring.dao;

import com.demo.spring.entity.Emp;

public interface EmpDao {
	
	
	public String saveEmp(Emp e);

}
