package com.demo.spring;


import java.util.HashMap;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("emp")
public class EmpRestController {
	
	static HashMap<Integer, Emp> empDb = new HashMap<>();

	static {
		
		empDb.put(100, new Emp(100, "Ankit", "Hyderabad", 56000));
		empDb.put(101, new Emp(101, "Malik", "Banglore", 56000));
		empDb.put(102, new Emp(102, "Kumar", "Chennai", 56000));
		empDb.put(103, new Emp(103, "Balu", "ooty", 56000));
		empDb.put(104, new Emp(104, "Hari", "Vizag", 56000));
		empDb.put(105, new Emp(105, "Suman", "pune", 56000));
		empDb.put(106, new Emp(106, "Madhu", "Bombay", 56000));
		empDb.put(107, new Emp(107, "Shiva", "Tuni", 56000));
		empDb.put(108, new Emp(108, "Rajesh", "KOti", 56000));
		empDb.put(109, new Emp(109, "Mani", "Thirupathi", 56000));
		
	}
	//@RequestMapping(path = "/find/{empid}", method = RequestMethod.GET)
	@GetMapping(path = "/find/{empid}", produces={MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity getById(@PathVariable("empid")int id)
	{
		if(empDb.containsKey(id))
		{
			Emp e = empDb.get(id);
			return ResponseEntity.ok(e);
		}
		else
		{
			return ResponseEntity.ok("Employee not Found!!");
		}
	}
	
	    @RequestMapping(path = "/save", method = RequestMethod.POST,consumes= MediaType.APPLICATION_JSON_VALUE, produces=MediaType.TEXT_PLAIN_VALUE)
		//@GetMapping(path = "/find/{empid}", produces={MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
		public ResponseEntity saveEmp(@RequestBody Emp e)
		{
			if(empDb.containsKey(e.getEmpId()))
			{
				
				return ResponseEntity.ok("The Emploee Exists");
			}
			else
			{
				empDb.put(e.getEmpId(), e);
				return ResponseEntity.ok("The Employee Saved..");
			}
		}
}
